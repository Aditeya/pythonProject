this repo contains info about the pixels project for the second year project module.

there is documentation of the system, simple examples and a basic simulator to enable you to work on and test code when you are at home, or the lights are not available.

